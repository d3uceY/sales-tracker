import React from 'react';
import { useTransactionData } from '../context/TransactionContext'; // Assuming this is your data hook
import { Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button'; // Assuming you use shadcn/ui
import { formatDate } from '../helpers/date/formatDate';
import { formatNgnCurrency } from '../helpers/currency/formatNaira';
import { formatUsdCurrency } from '../helpers/currency/formatDollars';
import { HistoryTableSkeleton } from './loader/historyTableLoader';

export default function HistoryTable() {
    const { transactions, loading: loadingTransactions } = useTransactionData()

    if (loadingTransactions) {
        return <HistoryTableSkeleton />;
    }

    if (!transactions || transactions.length === 0) {
        return (
            <div className="bg-gray-800 rounded-xl shadow-2xl p-8 text-center text-gray-400">
                <h3 className="text-xl font-medium">No Transactions Found</h3>
                <p>Add a new transaction to see your history here.</p>
            </div>
        );
    }

    return (
        <div className="bg-gray-800 rounded-xl shadow-2xl overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-300">
                    <thead className="text-xs text-gray-400 uppercase bg-gray-700">
                        <tr>
                            <th scope="col" className="px-6 py-4">Date</th>
                            <th scope="col" className="px-6 py-4">Customer</th>
                            <th scope="col" className="px-6 py-4">Item</th>
                            <th scope="col" className="px-6 py-4 text-right">Quantity</th>
                            <th scope="col" className="px-6 py-4 text-right">Price (USD)</th>
                            <th scope="col" className="px-6 py-4 text-right">Price (NGN)</th>
                            <th scope="col" className="px-6 py-4 text-right">Total (USD)</th>
                            <th scope="col" className="px-6 py-4 text-right">Total (NGN)</th>
                            <th scope="col" className="px-6 py-4 text-center">Status</th>
                            <th scope="col" className="px-6 py-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {transactions.map((transaction) => (
                            <tr key={transaction.id} className="border-b border-gray-700 hover:bg-gray-700/50 transition-colors duration-200">
                                <td className="px-6 py-4 font-medium whitespace-nowrap">{formatDate(transaction.transactionDate)}</td>
                                <td className="px-6 py-4">{transaction.customerName || transaction.customer}</td>
                                <td className="px-6 py-4">{transaction.itemPurchased || transaction.item}</td>
                                <td className="px-6 py-4 text-right font-mono">{transaction.quantity}</td>
                                <td className="px-6 py-4 text-right font-mono text-blue-400">{formatUsdCurrency(transaction.priceUSD || 0)}</td>
                                <td className="px-6 py-4 text-right font-mono text-yellow-400">{formatNgnCurrency(transaction.priceNGN || 0)}</td>
                                <td className="px-6 py-4 text-right font-mono text-cyan-400">{formatUsdCurrency(transaction.totalUSD || transaction.totalAmountUSD)}</td>
                                <td className="px-6 py-4 text-right font-mono text-emerald-400">{formatNgnCurrency(transaction.totalNGN || transaction.totalAmountNGN)}</td>
                                <td className="px-6 py-4 text-center">
                                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                        transaction.paymentStatus === 'paid' 
                                            ? 'bg-green-100 text-green-800' 
                                            : transaction.paymentStatus === 'partial'
                                            ? 'bg-yellow-100 text-yellow-800'
                                            : 'bg-red-100 text-red-800'
                                    }`}>
                                        {transaction.paymentStatus}
                                    </span>
                                </td>
                                <td className="px-6 py-4 text-center">
                                    <div className='flex justify-center items-center gap-2'>
                                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-gray-600">
                                            <Edit className="h-4 w-4 text-gray-400" />
                                        </Button>
                                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-red-900/50">
                                            <Trash2 className="h-4 w-4 text-red-500" />
                                        </Button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {/* Table Footer */}
            <div className="p-4 flex justify-between items-center text-gray-500 text-sm">
                {/* <span>
                    Showing <strong>{transactions.length}</strong> of <strong>{transactions.data?.meta?.total}</strong> results
                </span> */}
                <a href="#" className="hover:text-blue-400 transition-colors">View all transactions &rarr;</a>
            </div>
        </div>
    );
}


